#Write your code below this line 👇
def prime_checker(number):
  m = 0
  for x in range(2,10000):
    m += (not number%x)
  if m == 1:
    return print(f"{number} is a prime number")
  else:
    return print(f"{number} is not a prime number")

#Write your code above this line 👆
    
#Do NOT change any of the code below👇
n = int(input("Check this number: "))
prime_checker(number=n)



