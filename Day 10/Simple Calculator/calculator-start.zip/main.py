from art import logo
from replit import clear
def calculator(operator, n1,n2):
  '''Simple calculator function'''
  n1= float(n1)
  n2= float(n2)
  if operator == "+":
    n= n1+n2
  if operator == "-":
    n=n1-n2
  if operator == "*":
    n=n1*n2
  if operator == "/":
    n=n1/n2
  return n
#________________________________
new_calculation = True
while True:
  
  
  if new_calculation:
    clear()
    print(logo)
    n1 = input("What's the first number: ")
  else:
    n1=result
  operation = input("+\n-\n*\n/\nPick the operation: ")
  n2 = input("What's the next number?: "  )

  result =calculator(operation,n1,n2)
  print(f"{n1}{operation}{n2}= {result}")
  new_calculation= input(f"Type 'yes' for continue {result} calculation, or 'no' for new calculation.").lower() == 'no'
