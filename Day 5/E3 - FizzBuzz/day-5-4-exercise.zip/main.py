#Write your code below this row 👇

for x in range(0,101):
    #print(x)
    try:
        m=int(((x%5 and x%3)/(x%5 and x%3)))
    except:
        m=0
    print ((not x%3)*"Fizz " + (not x%5)*"Buzz " + str(x)*m)