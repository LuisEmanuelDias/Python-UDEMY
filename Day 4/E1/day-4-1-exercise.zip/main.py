#Write your code below this line 👇
#Hint: Remember to import the random module first. 🎲

import random

number = random.randint(0,1)


if number == 0:
  print("Head")
else:
  print("Tails")






